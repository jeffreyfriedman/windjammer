//! Heuristics for internal vs external (Cargo) crate paths when emitting `use`.

/// Module name prefixes treated as project-internal — `crate::` prepended where appropriate.
pub(in crate::codegen::rust) const COMMON_INTERNAL_MODULES: &[&str] = &[
    "math",
    "physics",
    "rendering",
    "world",
    "game",
    "audio",
    "input",
    "rpg",
    "ui",
    "editor",
    "scene",
    "collision2d",
    "networking",
    "effects",
    "animation",
    "ai",
    "dialogue",
    "inventory",
    "quest",
    "combat",
    "lighting",
    "camera",
    "particles",
    "terrain",
    "weather",
    "save",
    "config",
    "debug",
    "utils",
    "helpers",
    "core",
    "common",
    "types",
    "components",
    "systems",
    "resources",
    "entities",
    "events",
    "state",
    "assets",
    "data",
    "models",
    "controllers",
    "views",
    "managers",
    "services",
    "handlers",
    "processors",
];

/// Known external/crate module prefixes that should NOT get ::* added
pub(in crate::codegen::rust) const EXTERNAL_CRATE_MODULES: &[&str] =
    &["engine", "windjammer_runtime", "smallvec", "serde", "std"];

pub(in crate::codegen::rust) fn is_external_crate(first_segment: &str) -> bool {
    EXTERNAL_CRATE_MODULES.contains(&first_segment)
}

pub(in crate::codegen::rust) fn is_likely_internal_module(first_segment: &str) -> bool {
    COMMON_INTERNAL_MODULES.contains(&first_segment)
}
